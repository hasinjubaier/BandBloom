/**
 * Central label maps and helper functions for BandBloom Student Dashboard
 */

export const TEST_TYPE_LABELS: Record<string, string> = {
  general_training: "General Training",
  academic: "Academic",
};

export const SKILL_LABELS: Record<string, string> = {
  reading: "Reading",
  listening: "Listening",
  writing: "Writing",
  speaking: "Speaking",
  mock: "Mock Test",
};

export const ACTIVITY_TYPE_LABELS: Record<string, string> = {
  exam: "Mock Test",
  study: "Study Session",
  vocab: "Vocabulary",
  mistake: "Mistake Notebook",
};

export function formatTestType(type: string | undefined | null): string {
  if (!type) return "General Training";
  return TEST_TYPE_LABELS[type.toLowerCase()] || type.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export function formatSkill(skill: string | undefined | null): string {
  if (!skill) return "";
  return SKILL_LABELS[skill.toLowerCase()] || skill.charAt(0).toUpperCase() + skill.slice(1);
}

export function formatActivityType(type: string | undefined | null): string {
  if (!type) return "Activity";
  return ACTIVITY_TYPE_LABELS[type.toLowerCase()] || "Activity";
}

/**
 * Shared pluralization helper
 * e.g. pluralize(1, "day") -> "1 day"
 * e.g. pluralize(3, "day") -> "3 days"
 * e.g. pluralize(1, "mock test") -> "1 mock test"
 */
export function pluralize(count: number, singular: string, plural?: string): string {
  const word = count === 1 ? singular : plural || `${singular}s`;
  return `${count} ${word}`;
}

/**
 * Compute greeting in Asia/Dhaka timezone (SSR-safe and deterministic)
 */
export function getDhakaGreeting(date: Date = new Date()): string {
  try {
    const formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: "Asia/Dhaka",
      hour: "numeric",
      hour12: false,
    });
    const hour = parseInt(formatter.format(date), 10);
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  } catch {
    const hour = date.getUTCHours() + 6; // Dhaka is UTC+6
    const normalizedHour = (hour % 24 + 24) % 24;
    if (normalizedHour < 12) return "Good morning";
    if (normalizedHour < 18) return "Good afternoon";
    return "Good evening";
  }
}

/**
 * Compute days remaining until test in Asia/Dhaka timezone (SSR-safe)
 */
export function getDhakaDaysRemaining(targetDateStr: string, now: Date = new Date()): number {
  try {
    const formatter = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Dhaka",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
    const todayDhakaStr = formatter.format(now);
    const todayDhaka = new Date(`${todayDhakaStr}T00:00:00Z`);
    const cleanTarget = targetDateStr.slice(0, 10);
    const targetDhaka = new Date(`${cleanTarget}T00:00:00Z`);
    const diffMs = targetDhaka.getTime() - todayDhaka.getTime();
    return Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
  } catch {
    const examDate = new Date(targetDateStr);
    const timeDiff = examDate.getTime() - now.getTime();
    return Math.max(0, Math.ceil(timeDiff / (1000 * 3600 * 24)));
  }
}
