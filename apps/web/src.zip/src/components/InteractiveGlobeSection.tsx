"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import {
  BookOpen,
  Headphones,
  FileText,
  Mic,
  ArrowRight,
  Sparkles,
  Globe,
} from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { GlobeCanvas } from "./GlobeCanvas";

interface SkillCardData {
  id: "reading" | "listening" | "writing" | "speaking";
  titleKey: "readingTitle" | "listeningTitle" | "writingTitle" | "speakingTitle";
  descKey: "readingDesc" | "listeningDesc" | "writingDesc" | "speakingDesc";
  icon: React.ElementType;
  href: string;
  accentColor: string;
  iconBg: string;
  borderColor: string;
  hoverGlow: string;
  topAccent: string;
  ctaColor: string;
  focusRing: string;
  orbitPosition: "top" | "right" | "bottom" | "left";
  positionClass: string;
}

const SKILLS_CONFIG: SkillCardData[] = [
  {
    id: "reading",
    titleKey: "readingTitle",
    descKey: "readingDesc",
    icon: BookOpen,
    href: "/skills/reading",
    accentColor: "text-blue-600 dark:text-blue-400",
    iconBg: "bg-blue-50/90 dark:bg-blue-950/50 border-blue-200/80 dark:border-blue-800/60 shadow-[0_2px_8px_-2px_rgba(37,99,235,0.15)]",
    borderColor: "hover:border-blue-300/90 dark:hover:border-blue-500/80",
    hoverGlow: "hover:shadow-[0_12px_28px_-6px_rgba(37,99,235,0.16),0_4px_12px_-2px_rgba(37,99,235,0.08)]",
    topAccent: "bg-gradient-to-r from-blue-600 via-blue-500 to-sky-400",
    ctaColor: "text-blue-600 dark:text-blue-400",
    focusRing: "focus-visible:ring-blue-500",
    orbitPosition: "top",
    positionClass: "lg:top-2 lg:left-1/2 lg:-translate-x-1/2",
  },
  {
    id: "listening",
    titleKey: "listeningTitle",
    descKey: "listeningDesc",
    icon: Headphones,
    href: "/skills/listening",
    accentColor: "text-amber-600 dark:text-amber-400",
    iconBg: "bg-amber-50/90 dark:bg-amber-950/50 border-amber-200/80 dark:border-amber-800/60 shadow-[0_2px_8px_-2px_rgba(217,119,6,0.15)]",
    borderColor: "hover:border-amber-300/90 dark:hover:border-amber-500/80",
    hoverGlow: "hover:shadow-[0_12px_28px_-6px_rgba(217,119,6,0.16),0_4px_12px_-2px_rgba(217,119,6,0.08)]",
    topAccent: "bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400",
    ctaColor: "text-amber-600 dark:text-amber-400",
    focusRing: "focus-visible:ring-amber-500",
    orbitPosition: "right",
    positionClass: "lg:top-1/2 lg:right-2 lg:-translate-y-1/2",
  },
  {
    id: "writing",
    titleKey: "writingTitle",
    descKey: "writingDesc",
    icon: FileText,
    href: "/skills/writing",
    accentColor: "text-violet-600 dark:text-violet-400",
    iconBg: "bg-violet-50/90 dark:bg-violet-950/50 border-violet-200/80 dark:border-violet-800/60 shadow-[0_2px_8px_-2px_rgba(124,58,237,0.15)]",
    borderColor: "hover:border-violet-300/90 dark:hover:border-violet-500/80",
    hoverGlow: "hover:shadow-[0_12px_28px_-6px_rgba(124,58,237,0.16),0_4px_12px_-2px_rgba(124,58,237,0.08)]",
    topAccent: "bg-gradient-to-r from-violet-600 via-violet-500 to-purple-400",
    ctaColor: "text-violet-600 dark:text-violet-400",
    focusRing: "focus-visible:ring-violet-500",
    orbitPosition: "bottom",
    positionClass: "lg:bottom-2 lg:left-1/2 lg:-translate-x-1/2",
  },
  {
    id: "speaking",
    titleKey: "speakingTitle",
    descKey: "speakingDesc",
    icon: Mic,
    href: "/skills/speaking",
    accentColor: "text-[#FF7043] dark:text-[#FFA285]",
    iconBg: "bg-orange-50/90 dark:bg-orange-950/50 border-orange-200/80 dark:border-orange-800/60 shadow-[0_2px_8px_-2px_rgba(255,112,67,0.15)]",
    borderColor: "hover:border-orange-300/90 dark:hover:border-orange-500/80",
    hoverGlow: "hover:shadow-[0_12px_28px_-6px_rgba(255,112,67,0.16),0_4px_12px_-2px_rgba(255,112,67,0.08)]",
    topAccent: "bg-gradient-to-r from-[#FF7043] via-[#FF8A65] to-amber-400",
    ctaColor: "text-[#FF7043] dark:text-[#FFA285]",
    focusRing: "focus-visible:ring-[#FF7043]",
    orbitPosition: "left",
    positionClass: "lg:top-1/2 lg:left-2 lg:-translate-y-1/2",
  },
];

export function InteractiveGlobeSection() {
  const { t } = useLanguage();
  const [activeSkill, setActiveSkill] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const sectionRef = useRef<HTMLElement | null>(null);

  // Check reduced motion & scroll-triggered entrance sequence
  useEffect(() => {
    if (typeof window !== "undefined") {
      const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
      setPrefersReducedMotion(mediaQuery.matches);

      const handleChange = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
      mediaQuery.addEventListener("change", handleChange);

      // Intersection Observer for scroll-triggered entrance
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setIsVisible(true);
            }
          });
        },
        { threshold: 0.12 }
      );

      if (sectionRef.current) {
        observer.observe(sectionRef.current);
      }

      return () => {
        mediaQuery.removeEventListener("change", handleChange);
        observer.disconnect();
      };
    }
  }, []);

  return (
    <section
      ref={sectionRef}
      id="ielts-skills-universe"
      aria-labelledby="globe-section-title"
      className="relative w-full py-16 lg:py-24 min-h-[850px] lg:min-h-[calc(100svh-2rem)] flex flex-col justify-center items-center overflow-hidden bg-gradient-to-b from-transparent via-[#25A995]/5 to-transparent transition-colors duration-300"
    >
      {/* Decorative ambient background glows */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#25A995]/8 dark:bg-[#25A995]/15 blur-[140px] rounded-full pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/3 right-1/4 w-[400px] h-[400px] bg-[#FF8A65]/6 dark:bg-[#FF8A65]/10 blur-[120px] rounded-full pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 flex flex-col items-center">
        {/* Section Header */}
        <div
          className={`text-center max-w-3xl mx-auto mb-10 lg:mb-14 transition-all duration-700 ${
            isVisible || prefersReducedMotion
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-6"
          }`}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white dark:bg-[#123C3A] border border-[#D4E8E3] dark:border-[#205653] text-[#25A995] text-xs font-semibold shadow-xs mb-4">
            <Globe className="w-3.5 h-3.5 text-[#25A995]" aria-hidden="true" />
            <span>{t.globeSection.badge}</span>
            <Sparkles className="w-3.5 h-3.5 text-[#FF8A65]" aria-hidden="true" />
          </div>

          {/* Heading */}
          <h2
            id="globe-section-title"
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#123C3A] dark:text-[#F4FAF8] leading-[1.2] mb-4"
          >
            <span>{t.globeSection.titlePre}</span>{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#25A995] via-[#38bdf8] to-[#FF8A65]">
              {t.globeSection.titleHighlight}
            </span>
          </h2>

          {/* Supporting Text */}
          <p className="text-[#3D6462] dark:text-[#A0C5C1] text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
            {t.globeSection.subtitle}
          </p>
        </div>

        {/* =========================================================================
            DESKTOP & TABLET ORBITAL COMPOSITION (lg:block, hidden on mobile)
        ========================================================================= */}
        <div
          className={`relative w-full max-w-5xl h-[620px] hidden lg:flex items-center justify-center transition-all duration-1000 ${
            isVisible || prefersReducedMotion
              ? "opacity-100 scale-100"
              : "opacity-0 scale-95"
          }`}
        >
          {/* Orbital SVG Tracks & Connecting Rays */}
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none select-none z-0"
            viewBox="0 0 1024 620"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <defs>
              <linearGradient id="orbitGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#25A995" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#FF8A65" stopOpacity="0.35" />
              </linearGradient>

              <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#25A995" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#25A995" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Outer Orbit Ellipse */}
            <ellipse
              cx="512"
              cy="310"
              rx="410"
              ry="240"
              stroke="url(#orbitGrad)"
              strokeWidth="1.5"
              strokeDasharray="6 8"
              className="opacity-70"
            />

            {/* Inner Atmospheric Orbit Ellipse */}
            <ellipse
              cx="512"
              cy="310"
              rx="260"
              ry="160"
              stroke="#25A995"
              strokeWidth="1"
              strokeDasharray="4 6"
              className="opacity-40"
            />

            {/* Connecting Lines from Center/Orbit to 4 Cardinal Points */}
            {/* Top Node (Reading) */}
            <line
              x1="512"
              y1="190"
              x2="512"
              y2="105"
              stroke={activeSkill === "reading" ? "#3B82F6" : "#25A995"}
              strokeWidth={activeSkill === "reading" ? "2.5" : "1.5"}
              strokeDasharray={activeSkill === "reading" ? "none" : "3 4"}
              className="transition-all duration-300 opacity-60"
            />
            <circle
              cx="512"
              cy="105"
              r={activeSkill === "reading" ? "6" : "4"}
              fill={activeSkill === "reading" ? "#3B82F6" : "#25A995"}
              className="transition-all duration-300"
            />

            {/* Right Node (Listening) */}
            <line
              x1="630"
              y1="310"
              x2="745"
              y2="310"
              stroke={activeSkill === "listening" ? "#F59E0B" : "#25A995"}
              strokeWidth={activeSkill === "listening" ? "2.5" : "1.5"}
              strokeDasharray={activeSkill === "listening" ? "none" : "3 4"}
              className="transition-all duration-300 opacity-60"
            />
            <circle
              cx="745"
              cy="310"
              r={activeSkill === "listening" ? "6" : "4"}
              fill={activeSkill === "listening" ? "#F59E0B" : "#25A995"}
              className="transition-all duration-300"
            />

            {/* Bottom Node (Writing) */}
            <line
              x1="512"
              y1="430"
              x2="512"
              y2="515"
              stroke={activeSkill === "writing" ? "#8B5CF6" : "#25A995"}
              strokeWidth={activeSkill === "writing" ? "2.5" : "1.5"}
              strokeDasharray={activeSkill === "writing" ? "none" : "3 4"}
              className="transition-all duration-300 opacity-60"
            />
            <circle
              cx="512"
              cy="515"
              r={activeSkill === "writing" ? "6" : "4"}
              fill={activeSkill === "writing" ? "#8B5CF6" : "#25A995"}
              className="transition-all duration-300"
            />

            {/* Left Node (Speaking) */}
            <line
              x1="394"
              y1="310"
              x2="280"
              y2="310"
              stroke={activeSkill === "speaking" ? "#FF8A65" : "#25A995"}
              strokeWidth={activeSkill === "speaking" ? "2.5" : "1.5"}
              strokeDasharray={activeSkill === "speaking" ? "none" : "3 4"}
              className="transition-all duration-300 opacity-60"
            />
            <circle
              cx="280"
              cy="310"
              r={activeSkill === "speaking" ? "6" : "4"}
              fill={activeSkill === "speaking" ? "#FF8A65" : "#25A995"}
              className="transition-all duration-300"
            />
          </svg>

          {/* Centered 3D Earth Globe Canvas */}
          <div className="relative z-10 flex flex-col items-center">
            <GlobeCanvas size={390} />
          </div>

          {/* Four IELTS Skill Cards positioned symmetrically around the globe */}
          {SKILLS_CONFIG.map((skill, index) => {
            const Icon = skill.icon;
            const isHovered = activeSkill === skill.id;

            return (
              <div
                key={skill.id}
                className={`absolute z-20 w-64 xl:w-72 ${skill.positionClass} transition-all duration-700 ${
                  isVisible || prefersReducedMotion
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-6"
                }`}
                style={{
                  transitionDelay: prefersReducedMotion ? "0ms" : `${250 + index * 120}ms`,
                }}
              >
                <Link
                  href={skill.href}
                  onMouseEnter={() => setActiveSkill(skill.id)}
                  onMouseLeave={() => setActiveSkill(null)}
                  onFocus={() => setActiveSkill(skill.id)}
                  onBlur={() => setActiveSkill(null)}
                  className={`group relative block p-5 rounded-2xl bg-white dark:bg-[#123C3A] border border-[#DCEBE7] dark:border-[#1E4D4A] ${skill.borderColor} shadow-[0_4px_20px_-4px_rgba(18,60,58,0.06),0_2px_6px_-1px_rgba(18,60,58,0.04)] dark:shadow-[0_4px_20px_-4px_rgba(0,0,0,0.35)] ${skill.hoverGlow} transition-all duration-200 ease-out hover:-translate-y-1 focus-visible:outline-none focus-visible:ring-2 ${skill.focusRing} focus-visible:ring-offset-2 overflow-hidden`}
                  aria-label={`${t.globeSection[skill.titleKey]} - ${t.globeSection[skill.descKey]}`}
                >
                  {/* Subtle Colored Top Edge Accent */}
                  <div
                    className={`absolute top-0 inset-x-0 h-[3px] rounded-t-2xl ${skill.topAccent}`}
                    aria-hidden="true"
                  />

                  <div className="flex items-center gap-3.5 mb-2.5 pt-0.5">
                    <div
                      className={`w-10 h-10 rounded-xl ${skill.iconBg} border flex items-center justify-center shrink-0 group-hover:scale-105 group-hover:rotate-1 transition-transform duration-200`}
                    >
                      <Icon className={`w-5 h-5 ${skill.accentColor}`} aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-base font-bold text-[#123C3A] dark:text-[#F4FAF8] transition-colors duration-200">
                        {t.globeSection[skill.titleKey]}
                      </h3>
                    </div>
                  </div>

                  <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed mb-3.5">
                    {t.globeSection[skill.descKey]}
                  </p>

                  <div className={`flex items-center gap-1.5 text-xs font-bold ${skill.ctaColor}`}>
                    <span>{t.globeSection.ctaLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform duration-200" aria-hidden="true" />
                  </div>
                </Link>
              </div>
            );
          })}
        </div>

        {/* =========================================================================
            MOBILE & TABLET CLEAN RESPONSIVE STACK (block on mobile/tablet, hidden on lg)
        ========================================================================= */}
        <div className="w-full flex flex-col items-center lg:hidden space-y-8">
          {/* Centered Compact 3D Globe */}
          <div className="flex flex-col items-center">
            <GlobeCanvas size={270} />
          </div>

          {/* 4 Skill Cards in a clean, readable 2x2 grid (or 1-col on small screens) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-2xl">
            {SKILLS_CONFIG.map((skill) => {
              const Icon = skill.icon;
              return (
                <Link
                  key={skill.id}
                  href={skill.href}
                  className={`group relative block p-4 rounded-2xl bg-white dark:bg-[#123C3A] border border-[#DCEBE7] dark:border-[#1E4D4A] ${skill.borderColor} shadow-[0_4px_16px_-4px_rgba(18,60,58,0.06)] dark:shadow-[0_4px_16px_-4px_rgba(0,0,0,0.3)] ${skill.hoverGlow} transition-all duration-200 ease-out active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 ${skill.focusRing} overflow-hidden`}
                  aria-label={`${t.globeSection[skill.titleKey]} - ${t.globeSection[skill.descKey]}`}
                >
                  {/* Subtle Colored Top Edge Accent */}
                  <div
                    className={`absolute top-0 inset-x-0 h-[3px] rounded-t-2xl ${skill.topAccent}`}
                    aria-hidden="true"
                  />

                  <div className="flex items-center gap-3 mb-2.5 pt-0.5">
                    <div
                      className={`w-9 h-9 rounded-xl ${skill.iconBg} border flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200`}
                    >
                      <Icon className={`w-4.5 h-4.5 ${skill.accentColor}`} aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-bold text-[#123C3A] dark:text-[#F4FAF8]">
                        {t.globeSection[skill.titleKey]}
                      </h3>
                    </div>
                  </div>

                  <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed mb-3">
                    {t.globeSection[skill.descKey]}
                  </p>

                  <div className={`flex items-center gap-1.5 text-xs font-bold ${skill.ctaColor}`}>
                    <span>{t.globeSection.ctaLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform duration-200" aria-hidden="true" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
