import { NextResponse } from "next/server";
import { getSessionUser, requireAuth } from "@/server/auth/session";
import {
  getMistakeNotes,
  addMistakeNote,
} from "@/server/services/learning.service";

export async function GET(request: Request) {
  try {
    const user = await getSessionUser(request);
    if (!user) {
      return NextResponse.json({
        success: true,
        mistakes: [],
        authenticated: false,
      });
    }

    const mistakes = await getMistakeNotes(user.id);
    return NextResponse.json({
      success: true,
      mistakes,
      authenticated: true,
    });
  } catch (error: any) {
    const isConnError = error?.code === "ECONNREFUSED" || error?.code === "ETIMEDOUT";
    return NextResponse.json(
      {
        success: false,
        error: isConnError
          ? "Database service temporarily unreachable."
          : "Failed to load mistake notebook.",
      },
      { status: isConnError ? 503 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const user = await requireAuth(request);

    const body = await request.json();
    const { skill, errorTag, userNotes, originalAnswer, correctReasoning, questionId, attemptId } = body;

    if (!skill || !errorTag) {
      return NextResponse.json(
        { success: false, error: "Skill and errorTag are required." },
        { status: 400 }
      );
    }

    const newId = await addMistakeNote(user.id, {
      skill,
      errorTag,
      userNotes,
      originalAnswer,
      correctReasoning,
      questionId,
      attemptId,
    });

    return NextResponse.json({
      success: true,
      id: newId,
      message: "Mistake recorded in personal notebook.",
    });
  } catch (error: any) {
    const status = error.status || (error?.code === "ECONNREFUSED" ? 503 : 500);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to record mistake note." },
      { status }
    );
  }
}
