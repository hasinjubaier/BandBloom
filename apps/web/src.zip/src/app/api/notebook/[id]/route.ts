import { NextResponse } from "next/server";
import { requireAuth } from "@/server/auth/session";
import {
  updateMistakeStatus,
  deleteMistakeNote,
} from "@/server/services/learning.service";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: noteId } = await params;
    const user = await requireAuth(request);

    const body = await request.json();
    const { status } = body;

    const validStatus = status === "mastered" ? "mastered" : "pending";
    const ok = await updateMistakeStatus(user.id, noteId, validStatus);

    if (!ok) {
      return NextResponse.json(
        { success: false, error: "Note not found or access denied." },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: `Mistake status marked as ${validStatus}.`,
    });
  } catch (error: any) {
    const status = error.status || (error?.code === "ECONNREFUSED" ? 503 : 500);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update mistake status." },
      { status }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: noteId } = await params;
    const user = await requireAuth(request);

    const ok = await deleteMistakeNote(user.id, noteId);

    if (!ok) {
      return NextResponse.json(
        { success: false, error: "Note not found or access denied." },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Mistake note deleted from notebook.",
    });
  } catch (error: any) {
    const status = error.status || (error?.code === "ECONNREFUSED" ? 503 : 500);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to delete mistake note." },
      { status }
    );
  }
}
