import { NextResponse } from "next/server";
import { getSessionUser } from "@/server/auth/session";
import { getVocabularyWithProgress } from "@/server/services/learning.service";

export async function GET(request: Request) {
  try {
    const user = await getSessionUser(request);
    // Shared academic vocabulary bank can be accessed publicly; progress is joined if authenticated
    const vocabulary = await getVocabularyWithProgress(user?.id || "");
    return NextResponse.json({
      success: true,
      vocabulary,
      authenticated: Boolean(user),
    });
  } catch (error: any) {
    const isConnError = error?.code === "ECONNREFUSED" || error?.code === "ETIMEDOUT";
    return NextResponse.json(
      {
        success: false,
        error: isConnError
          ? "Database service temporarily unreachable."
          : "Failed to load vocabulary list.",
      },
      { status: isConnError ? 503 : 500 }
    );
  }
}
