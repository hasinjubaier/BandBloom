import { NextResponse } from "next/server";
import { requireAuth } from "@/server/auth/session";
import { advanceVocabularyMastery } from "@/server/services/learning.service";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: vocabId } = await params;
    const user = await requireAuth(request);

    const result = await advanceVocabularyMastery(user.id, vocabId);

    return NextResponse.json({
      success: true,
      result,
    });
  } catch (error: any) {
    const status = error.status || (error?.code === "ECONNREFUSED" ? 503 : 500);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update vocabulary progress." },
      { status }
    );
  }
}
