import { NextResponse } from "next/server";
import { getSessionUser, requireAuth } from "@/server/auth/session";
import {
  getActiveStudyPlan,
  toggleStudyPlanTask,
} from "@/server/services/learning.service";

export async function GET(request: Request) {
  try {
    const user = await getSessionUser(request);

    // For authenticated users, retrieve their personalized plan
    if (user) {
      const tasks = await getActiveStudyPlan(user.id);
      return NextResponse.json({
        success: true,
        tasks,
        authenticated: true,
      });
    }

    // For unauthenticated visitors, return legitimate empty plan state
    return NextResponse.json({
      success: true,
      tasks: [],
      authenticated: false,
    });
  } catch (error: any) {
    const isConnError = error?.code === "ECONNREFUSED" || error?.code === "ETIMEDOUT";
    return NextResponse.json(
      {
        success: false,
        error: isConnError
          ? "Database service temporarily unreachable."
          : "Failed to load study plan.",
      },
      { status: isConnError ? 503 : 500 }
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const user = await requireAuth(request);
    const body = await request.json();
    const { taskId } = body;

    if (!taskId) {
      return NextResponse.json(
        { success: false, error: "Task ID is required." },
        { status: 400 }
      );
    }

    const updatedTasks = await toggleStudyPlanTask(user.id, taskId);
    return NextResponse.json({
      success: true,
      tasks: updatedTasks,
    });
  } catch (error: any) {
    const status = error.status || (error?.code === "ECONNREFUSED" ? 503 : 500);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update study task." },
      { status }
    );
  }
}
