"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Sparkles,
  BookOpen,
  Headphones,
  FileText,
  Mic,
  BrainCircuit,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Laptop,
  Clock,
  ShieldCheck,
  TrendingUp,
  Award,
  Zap,
  HelpCircle,
  BarChart3,
  BookmarkCheck,
} from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { useExam } from "@/context/ExamContext";
import { ScoreCalculatorModal } from "@/components/ScoreCalculatorModal";
import { InteractiveGlobeSection } from "@/components/InteractiveGlobeSection";
import { HowItWorksSection } from "@/components/HowItWorksSection";
import { FreeLessonsSampleSection } from "@/components/FreeLessonsSampleSection";
import { WeeklyMockTestsSection } from "@/components/WeeklyMockTestsSection";
import { StudyPlanProgressSection } from "@/components/StudyPlanProgressSection";
import { AITutorFeedbackSection } from "@/components/AITutorFeedbackSection";
import { FinalCTASection } from "@/components/FinalCTASection";

export default function HomePage() {
  const { language, t } = useLanguage();
  const { profile, updateProfile } = useExam();
  const [calcOpen, setCalcOpen] = useState(false);
  const [selectedTargetBand, setSelectedTargetBand] = useState<number | null>(null);

  useEffect(() => {
    const validBands = [6.5, 7.0, 7.5, 8.0, 8.5];
    const saved = localStorage.getItem("bandbloom_target_band");
    if (saved) {
      const parsed = parseFloat(saved);
      if (!isNaN(parsed) && validBands.includes(parsed)) {
        setSelectedTargetBand(parsed);
        return;
      }
    }
    if (
      profile?.targetBand &&
      validBands.includes(profile.targetBand) &&
      localStorage.getItem("bandbloom_has_chosen_goal")
    ) {
      setSelectedTargetBand(profile.targetBand);
    }
  }, [profile?.targetBand]);

  const handleBandSelect = (band: number) => {
    setSelectedTargetBand(band);
    updateProfile({ targetBand: band });
    if (typeof window !== "undefined") {
      localStorage.setItem("bandbloom_target_band", String(band));
      localStorage.setItem("bandbloom_has_chosen_goal", "true");
    }
  };

  return (
    <div className="flex flex-col gap-20 pb-24">
      {/* Hero Section */}
      <section id="home" className="relative pt-8 pb-16 overflow-hidden scroll-mt-20">
        {/* Glow background decorations */}
        {/* Glow background decorations */}
        <div className="absolute top-0 left-1/4 -translate-x-1/2 w-[500px] h-[350px] bg-[#25A995]/8 dark:bg-[#25A995]/15 blur-[120px] pointer-events-none rounded-full" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Content Column (5 cols on lg) */}
            <div className="lg:col-span-5 text-left space-y-6">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white dark:bg-[#123C3A] border border-[#D4E8E3] dark:border-[#205653] text-[#25A995] text-xs font-semibold shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-[#25A995]" />
                <span>{t.hero.badge}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF8A65] animate-pulse" />
              </div>

              {/* Heading */}
              <h1 className="text-3xl sm:text-4xl lg:text-[2.75rem] font-extrabold tracking-tight leading-[1.15]">
                <span className="block text-[#123C3A] dark:text-[#F4FAF8]">{t.hero.titlePre}</span>
                <span className="block bg-clip-text text-transparent bg-gradient-to-r from-[#25A995] to-[#FF8A65]">
                  {t.hero.titleHighlight}
                </span>
                {t.hero.titlePost ? <span className="text-[#123C3A] dark:text-[#F4FAF8]"> {t.hero.titlePost}</span> : null}
              </h1>

              {/* Subtitle */}
              <p className="text-[#3D6462] dark:text-[#A0C5C1] text-base sm:text-[17px] leading-relaxed max-w-xl">
                {t.hero.subtitle}
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-1">
                <Link
                  href="/onboarding"
                  className="px-6 py-3.5 rounded-xl bg-[#25A995] hover:bg-[#123C3A] text-white font-semibold text-sm sm:text-base shadow-lg shadow-[#25A995]/20 border border-transparent transition-all flex items-center justify-center gap-2 group whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#25A995] focus-visible:ring-offset-2"
                >
                  <span>{t.hero.primaryCta}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" aria-hidden="true" />
                </Link>

                <Link
                  href="/mock-centre"
                  className="px-6 py-3.5 rounded-xl bg-white hover:bg-[#F4FAF8] border border-[#D4E8E3] text-[#123C3A] hover:border-[#25A995] dark:bg-[#123C3A] dark:hover:bg-[#0A1C1B] dark:border-[#205653] dark:text-[#F4FAF8] font-medium text-sm sm:text-base transition-all flex items-center justify-center gap-2 shadow-xs whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#25A995] focus-visible:ring-offset-2"
                >
                  <Laptop className="w-4 h-4 text-[#FF8A65]" aria-hidden="true" />
                  <span>{t.hero.secondaryCta}</span>
                </Link>
              </div>

              {/* Trust points */}
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2.5 pt-5 border-t border-[#D4E8E3] dark:border-[#205653] text-xs sm:text-[13px] text-[#3D6462] dark:text-[#A0C5C1]">
                <span className="flex items-center gap-1.5 font-medium">
                  <Sparkles className="w-4 h-4 text-[#25A995]" aria-hidden="true" />
                  <span>{t.hero.trustFreePractice}</span>
                </span>
                <span className="flex items-center gap-1.5 font-medium">
                  <BookOpen className="w-4 h-4 text-[#FF8A65]" aria-hidden="true" />
                  <span>{t.hero.trustAllSkills}</span>
                </span>
                <span className="flex items-center gap-1.5 font-medium">
                  <BrainCircuit className="w-4 h-4 text-[#25A995]" aria-hidden="true" />
                  <span>{t.hero.trustAiGuidance}</span>
                </span>
                <span className="flex items-center gap-1.5 font-medium">
                  <ShieldCheck className="w-4 h-4 text-[#FF8A65]" aria-hidden="true" />
                  <span>{t.hero.trustUnofficialScores}</span>
                </span>
              </div>
            </div>

            {/* Right Visual Column (Isolated transparent elements on website background) */}
            <div className="lg:col-span-7 relative w-full flex items-center justify-center">
              <div className="relative w-full max-w-2xl lg:max-w-none group flex justify-center">
                <img
                  src="/hero-ielts-v4.png"
                  alt="IELTS Preparation Books - Reading, Listening, Writing, Speaking with study materials and graduation cap"
                  className="w-full h-auto object-contain transition-transform duration-500 hover:scale-[1.01] pointer-events-none select-none"
                />
              </div>
            </div>
          </div>

          {/* Select Your Goal Band Row (Spanning full container width below two-column hero content) */}
          <div className="mt-8 lg:mt-12 w-full">
            <div className="w-full flex flex-col md:flex-row items-center justify-between gap-4 p-4 sm:p-5 bg-white dark:bg-[#123C3A] border border-[#D4E8E3] dark:border-[#205653] rounded-2xl shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#25A995]/10 dark:bg-[#25A995]/20 flex items-center justify-center text-[#25A995] shrink-0">
                  <Award className="w-5 h-5 text-[#25A995]" aria-hidden="true" />
                </div>
                <div className="text-left">
                  <h2 className="text-sm sm:text-base font-bold text-[#123C3A] dark:text-[#F4FAF8]">
                    {t.hero.targetHeading}
                  </h2>
                  <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1]">
                    {t.hero.targetDesc}
                  </p>
                </div>
              </div>

              <div
                className="flex items-center gap-2 flex-wrap justify-center sm:justify-end w-full md:w-auto"
                role="group"
                aria-label={t.hero.targetHeading}
              >
                {[6.5, 7.0, 7.5, 8.0, 8.5].map((band) => {
                  const isSelected = selectedTargetBand === band;
                  return (
                    <button
                      key={band}
                      onClick={() => handleBandSelect(band)}
                      aria-pressed={isSelected}
                      className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold min-h-[40px] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#25A995] focus-visible:ring-offset-2 transition-all ${
                        isSelected
                          ? "bg-[#25A995] text-white shadow-md shadow-[#25A995]/30 scale-105"
                          : "text-[#3D6462] hover:text-[#123C3A] hover:bg-[#F4FAF8] dark:text-[#A0C5C1] dark:hover:text-[#F4FAF8] dark:hover:bg-[#0A1C1B]"
                      }`}
                    >
                      Band {band.toFixed(1)}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Full-Screen Interactive 3D Earth Globe Section */}
      <InteractiveGlobeSection />

      {/* Four Skill Labs Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#123C3A] dark:text-[#F4FAF8] tracking-tight mb-3">
            {t.features.heading}
          </h2>
          <p className="text-[#3D6462] dark:text-[#A0C5C1] text-sm">
            {t.features.subheading}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Reading Card */}
          <div className="bg-white dark:bg-[#123C3A] p-6 rounded-2xl border border-[#D4E8E3] dark:border-[#205653] hover:border-[#25A995] shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#E8F7F4] dark:bg-[#0A1C1B] border border-[#25A995]/30 flex items-center justify-center text-[#25A995] mb-5 group-hover:scale-105 transition-transform shadow-xs">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-[#123C3A] dark:text-[#F4FAF8] mb-2">{t.features.readingTitle}</h3>
              <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed mb-4">
                {t.features.readingDesc}
              </p>
            </div>
            <Link
              href="/skills/reading"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#25A995] hover:text-[#123C3A] dark:hover:text-[#F4FAF8] pt-3 border-t border-[#D4E8E3] dark:border-[#205653]"
            >
              <span>{language === "bn" ? "রিডিং ল্যাব শুরু করুন" : "Open Reading Lab"}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Listening Card */}
          <div className="bg-white dark:bg-[#123C3A] p-6 rounded-2xl border border-[#D4E8E3] dark:border-[#205653] hover:border-[#25A995] shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#E8F7F4] dark:bg-[#0A1C1B] border border-[#25A995]/30 flex items-center justify-center text-[#25A995] mb-5 group-hover:scale-105 transition-transform shadow-xs">
                <Headphones className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-[#123C3A] dark:text-[#F4FAF8] mb-2">{t.features.listeningTitle}</h3>
              <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed mb-4">
                {t.features.listeningDesc}
              </p>
            </div>
            <Link
              href="/skills/listening"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#25A995] hover:text-[#123C3A] dark:hover:text-[#F4FAF8] pt-3 border-t border-[#D4E8E3] dark:border-[#205653]"
            >
              <span>{language === "bn" ? "লিসেনিং ল্যাব শুরু করুন" : "Open Listening Lab"}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Writing Card - Coral Accent */}
          <div className="bg-white dark:bg-[#123C3A] p-6 rounded-2xl border border-[#D4E8E3] dark:border-[#205653] hover:border-[#FF8A65] shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#FFF6F3] dark:bg-[#0A1C1B] border border-[#FF8A65]/30 flex items-center justify-center text-[#FF8A65] mb-5 group-hover:scale-105 transition-transform shadow-xs">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-[#123C3A] dark:text-[#F4FAF8] mb-2">{t.features.writingTitle}</h3>
              <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed mb-4">
                {t.features.writingDesc}
              </p>
            </div>
            <Link
              href="/skills/writing"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#FF8A65] hover:opacity-80 pt-3 border-t border-[#D4E8E3] dark:border-[#205653]"
            >
              <span>{language === "bn" ? "রাইটিং ল্যাব শুরু করুন" : "Open Writing Lab"}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Speaking Card - Coral Accent */}
          <div className="bg-white dark:bg-[#123C3A] p-6 rounded-2xl border border-[#D4E8E3] dark:border-[#205653] hover:border-[#FF8A65] shadow-xs hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-xl bg-[#FFF6F3] dark:bg-[#0A1C1B] border border-[#FF8A65]/30 flex items-center justify-center text-[#FF8A65] mb-5 group-hover:scale-105 transition-transform shadow-xs">
                <Mic className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-[#123C3A] dark:text-[#F4FAF8] mb-2">{t.features.speakingTitle}</h3>
              <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed mb-4">
                {t.features.speakingDesc}
              </p>
            </div>
            <Link
              href="/skills/speaking"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#FF8A65] hover:opacity-80 pt-3 border-t border-[#D4E8E3] dark:border-[#205653]"
            >
              <span>{language === "bn" ? "স্পিকিং ল্যাব শুরু করুন" : "Open Speaking Lab"}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <HowItWorksSection />

      {/* Free Lessons & Sample Practice Section */}
      <FreeLessonsSampleSection />

      {/* Weekly Mock Tests Section */}
      <WeeklyMockTestsSection />

      {/* Study Plan & Progress Section */}
      <StudyPlanProgressSection />

      {/* 2026 Computer-Delivered Transition Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="bg-white dark:bg-[#123C3A] border border-[#D4E8E3] dark:border-[#205653] rounded-3xl p-8 sm:p-10 relative overflow-hidden shadow-sm dark:shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-2 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-[#FFF6F3] dark:bg-[#0A1C1B] text-[#FF8A65] border border-[#FF8A65]/30 text-xs font-semibold">
                <Laptop className="w-3.5 h-3.5" />
                <span>March 2026 Test Delivery Standard</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-[#123C3A] dark:text-[#F4FAF8] tracking-tight">
                {language === "bn"
                  ? "মধ্য-২০২৬ থেকে সম্পূর্ণ কম্পিউটার-ডেলিভার্ড পরীক্ষা"
                  : "Fully Aligned with Global Computer-Delivered IELTS"}
              </h3>
              <p className="text-sm text-[#3D6462] dark:text-[#A0C5C1] leading-relaxed">
                {language === "bn"
                  ? "অফিসিয়াল IELTS ঘোষণা অনুযায়ী পেপার-বেসড পরীক্ষা ক্রমান্বয়ে বন্ধ হচ্ছে। BandBloom পরীক্ষার্থীদের আসল কম্পিউটার সফটওয়্যারের মতো স্প্লিট-স্ক্রিন প্যাসেজ ভিউ, ড্র্যাগ-এন্ড-ড্রপ এবং নির্ভরযোগ্য অন-স্ক্রিন টাইমার অভ্যস্ত করে তোলে।"
                  : "IELTS test centers worldwide are transitioning primarily to computer delivery. BandBloom trains you on the exact UX: responsive split-screen reading, on-the-fly text highlighting, authoritative server timers, and One Skill Retake strategy."}
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <div className="flex items-center gap-2 text-xs text-[#3D6462] dark:text-[#A0C5C1]">
                  <CheckCircle2 className="w-4 h-4 text-[#25A995]" />
                  <span>One Skill Retake Strategy</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-[#3D6462] dark:text-[#A0C5C1]">
                  <CheckCircle2 className="w-4 h-4 text-[#25A995]" />
                  <span>Split-Screen Reading & Auto-Save</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-[#3D6462] dark:text-[#A0C5C1]">
                  <CheckCircle2 className="w-4 h-4 text-[#FF8A65]" />
                  <span>Network Grace-Window Protection</span>
                </div>
              </div>
            </div>

            <div className="bg-[#F4FAF8] dark:bg-[#0A1C1B] border border-[#D4E8E3] dark:border-[#205653] rounded-2xl p-6 text-center space-y-4 shadow-xs">
              <Award className="w-10 h-10 text-[#25A995] mx-auto" />
              <h4 className="text-base font-bold text-[#123C3A] dark:text-[#F4FAF8]">
                {language === "bn" ? "অফিসিয়াল রাউন্ডিং হিসাব" : "Official Score Rounding"}
              </h4>
              <p className="text-xs text-[#3D6462] dark:text-[#A0C5C1]">
                {language === "bn"
                  ? "আপনার কাঙ্ক্ষিত ব্যান্ডের গাণিতিক মান যাচাই করুন"
                  : "Check how fractional scores round up officially"}
              </p>
              <button
                onClick={() => setCalcOpen(true)}
                className="w-full py-2.5 px-4 rounded-xl bg-[#25A995] hover:bg-[#123C3A] text-white text-xs font-semibold shadow-md shadow-[#25A995]/20 transition-colors"
              >
                {language === "bn" ? "ক্যালকুলেটর খুলুন" : "Open Score Simulator"}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* AI Tutor & Feedback Section */}
      <AITutorFeedbackSection />

      {/* Final Call to Action Section */}
      <FinalCTASection />

      <ScoreCalculatorModal isOpen={calcOpen} onClose={() => setCalcOpen(false)} />
    </div>
  );
}
